//Copyright(c) 2016 Viktor Kuropiatnyk "BoredEngineer"

#include "MMT.h"
#include "MMTPluginPCH.h"

void MMTImpl::StartupModule()
{
}
 
void MMTImpl::ShutdownModule()
{
}
 
IMPLEMENT_MODULE(MMTImpl, MMT)